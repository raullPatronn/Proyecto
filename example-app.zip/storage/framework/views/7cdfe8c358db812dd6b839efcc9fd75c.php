<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<script>
$(document).ready(function(){
    $('#toggleMenu').click(function(){
      $('#menu').slideToggle();
    });
  });
</script>
<div class="lg:mt-4 md:mr-2 lg:mb-16 md:mb-2 mb-2" style="padding: 20px;">
  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal-message', [])->html();
} elseif ($_instance->childHasBeenRendered('l2285549155-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2285549155-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2285549155-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2285549155-0');
} else {
    $response = \Livewire\Livewire::mount('modal-message', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2285549155-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  <!---Contenido/////////////////////////////////--->
  <div class="container mx-auto flex flex-wrap items-center justify-center ">
    <div class="w-full md:w-1/2 md:pr-20 mt-20 ml:mt-28 md:mt-8 ">
      <div class="text-center mb-8">
        <h1 class="lg:text-6xl font-bold bg-clip-text text-sky-950 font-serif animate__animated animate__fadeInLeft md:text-5xl text-3xl md:mr-4 text-center lg:ml-16 lg:mr-16" style="font-family: Georgia, serif;">¿Necesitas una mano?</h1>
      </div>
      <p class="text-sky-950 text-center text-lg mb-16 font-sans italic animate__animated animate__fadeInLeft">Ofrecemos ayuda emocional y apoyo para quienes lo necesiten. Puede revisar su menú de servicios.</p>
      <!---Menu/////////////////////////////////---> 
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Solicitar-Ayuda')): ?> 
      <div class="bg-gray-200 shadow-md rounded-md mb-4">
        <div class="flex items-center justify-between bg-blue-400 text-white px-4 py-3 rounded-t-md shadow-md" id="toggleMenu">
          <h2 class="font-bold">Menú de servicios</h2>
          <svg class="h-6 w-6 cursor-pointer text-white transition-colors duration-300 ease-in-out" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M4 6h16M4 12h16M4 18h16"></path>
          </svg>
        </div>
        <!---Menu/////////////////////////////////--->
        <div id="menu" class="hidden p-4 bg-blue-100 shadow-md">
          <ul class="list-none">
            <?php $__currentLoopData = $opcionesMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="mb-2">
              <a href="<?php echo e($opcion['ruta']); ?>" class="block py-2 px-4 bg-blue-400 hover:bg-red-300 rounded-md transition-colors duration-300 italic text-white text-lg"><?php echo e($opcion['nombre']); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Brindar-Ayuda')): ?>
        <div class="bg-gray-200 shadow-md rounded-md mb-4">
        <div class="flex items-center justify-between bg-blue-400 text-white px-4 py-3 rounded-t-md shadow-md" id="toggleMenu">
          <h2 class="font-bold">Menú de servicios</h2>
          <svg class="h-6 w-6 cursor-pointer text-white transition-colors duration-300 ease-in-out" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M4 6h16M4 12h16M4 18h16"></path>
          </svg>
        </div>
        <!---Menu/////////////////////////////////--->
        <div id="menu" class="hidden p-4 bg-blue-100 shadow-md">
          <ul class="list-none">
            <?php $__currentLoopData = $opcionesMenu2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="mb-2">
              <a href="<?php echo e($opcion['ruta']); ?>" class="block py-2 px-4 bg-blue-400 hover:bg-red-300 rounded-md transition-colors duration-300 italic text-white text-lg"><?php echo e($opcion['nombre']); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
        <!---Administrador y Super Administrador /////////////////////////////--->
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin|Super-Admin')): ?>
        <div class="rounded-md mb-4">
          <?php $__currentLoopData = $opcionesRedirect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <a href="<?php echo e($opcion['ruta']); ?>" class="font-semibold text-white hover:text-gray-700 focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500 bg-purple-500 py-3 px-6 rounded-full shadow-md transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 ">Asignar roles</a>  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('vista-admin', [])->html();
} elseif ($_instance->childHasBeenRendered('l2285549155-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2285549155-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2285549155-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2285549155-1');
} else {
    $response = \Livewire\Livewire::mount('vista-admin', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2285549155-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
      </div>
    </div>
    <!---SVG////////////////////////////////--->
    <div class="w-full md:w-1/2 flex justify-center md:justify-end mt-72 space-x-10 md:-space-x-10 ">
      <svg xmlns="http://www.w3.org/2000/svg" id="uuid-0614f311-aab0-4d23-a66b-2f5463302726" width="700" height="300" viewBox="0 0 692.68042 327.47189" class="injected-svg ClassicGrid__ImageFile-sc-td9pmq-4 fNAcXv grid_media" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M207.95311,68.81363c.05771,.00986,.1442,.0245,.24904,.04185,2.05136,.33957,14.45374,2.25308,26.95784-2.51012,5.29715-2.01785,3.49015-2.52077,15.28773-9.53614,13.83138-8.22473,17.38101-8.16726,18.41101-12.0023,2.05667-7.65797-8.92542-19.69644-16.19439-18.90382-1.91376,.20869-3.96328,1.34963-7.15104,.57599-.70038-.16997-3.76626-.91402-5.26088-3.4518-1.33332-2.26389-.20403-3.89699-.74025-5.7537-1.40748-4.87362-13.14017-7.30582-23.42653-5.58734-5.91628,.98842-10.51802,3.68683-19.47981,9.04331-15.59837,9.32311-23.39745,13.98468-25.15035,21.1267-1.66142,6.76936,2.32619,9.68618-.57391,16.93255-2.70041,6.74725-6.98935,6.29661-8.46524,11.75484-2.37505,8.78336,6.44004,18.42314,10.11211,22.4388,4.02599,4.40267,7.87633,6.81902,12.98792,10.02686,6.41596,4.02642,9.62385,6.03962,13.48076,5.83479,6.99272-.37136,27.77163,.89278,28.04263-4.8939,.10155-2.16864,25.30287-.39298,12.89362-23.7409-1.52204-2.86374-31.3393,.19518-31.73285-1.44996" fill="#2f2e41"></path><polygon points="492.19363 301.23849 521.24635 303.86831 557.32791 322.19307 563.27837 300.94149 568.4751 274.03646 557.64851 261.28551 538.94711 274.03646 499.84419 269.78612 492.19363 301.23849" fill="#ffb6b6"></polygon><polygon points="253.32578 212.83187 231.22415 321.64 391.88614 275.73659 495.59389 304.63875 510.89502 271.48626 396.13644 223.03264 301.77942 224.73278 253.32578 212.83187" fill="#2f2e41"></polygon><path d="M560.58812,272.88506l3.40025,2.5502-21.11156,39.95731s14.26097,8.32013,18.51129,8.32013,18.75149-82.28,17.05136-94.43188c-1.70012-12.15189-12.75095-8.24963-12.75095-8.24963l-23.85457,50.39401,18.7542,1.45987h-.00003Z" fill="#2f2e41"></path><path d="M90.19861,259.08639c-2.22827-.23975-3.09741,2.81052-1.08447,3.79572,2.91522,1.42682,5.65747,3.22449,7.08679,5.35333,3.6543,5.44269,8.70343,2.29651,9.42133,1.80804,1.18036,1.96481,1.76154,3.95047,2.01196,5.71582l-1.72217,5.7063c-.07495,.38126,.0033-.0112,0,0h0l-1.32019,14.52243c-.90436,3.52759-.22186,6.92426,0,7.92133l-1.32019,18.48309,3.69104,.02966,.39789-18.08258,.07703-.02258c-.00214-.00742-.03003-.10638-.07031-.28308l.16443-7.47186c.33209-1.27954,.85791-2.6243,1.65973-3.95911,.7179,.48846,5.76703,3.63461,9.42133-1.80804,1.42932-2.12885,4.17157-3.92651,7.08679-5.35333,2.013-.98523,1.1438-4.03546-1.08447-3.79572-1.88776,.20312-3.94708,.50797-6.13757,.95401-9.28784,1.8912-9.48071,8.19778-9.39935,9.64383l-.06311-.03937c-.6344,1.0177-1.10504,2.04324-1.45447,3.04532l.30957-14.06967c.19177-.9967,2.33801-2.57559,2.0025-4.99521l-1.43542-20.77673c.50684,.87027,1.06842,1.43546,1.59839,1.37494,1.26727-.14471,1.90594-3.81177,1.74548-6.48105,1.57483,2.18188,4.56189,4.71756,5.651,3.98901,.8241-.5513,.33545-2.82092-.56433-4.88434,1.87482,1.12949,3.95117,1.87186,4.59552,1.15463,.87921-.97873-1.2276-4.31827-3.17059-6.18246,2.60083,.24255,5.90857-.17181,6.12543-1.3555,.17871-.97531-1.78992-2.20596-3.89703-2.99805,2.11639-.55804,4.09552-1.53036,4.02991-2.49228-.09351-1.37027-4.30072-2.19919-6.99231-2.01553-.15497,.01056-.3006,.02463-.43921,.04132,2.30585-1.3985,5.14258-4.28232,4.47894-5.43753-.4939-.85974-2.79156-.52673-4.91144,.2305,1.25452-1.79355,2.13647-3.81458,1.46478-4.50623-.95691-.98526-4.70325,1.10098-6.63861,2.98053-.18018,.17499-.33813,.34195-.47601,.50177,.00696-.13718,.01099-.28073,.01099-.43323,0-2.69788-1.1134-6.83887-2.48688-6.83887-.96411,0-1.7995,2.04074-2.21216,4.19025-.93365-2.04828-2.29547-3.92859-3.25635-3.68393-1.14856,.29245-1.34802,3.52484-.95349,6.08563-2.02661-1.64374-4.99622-3.1308-5.83295-2.26923-.67169,.69165,.21027,2.71268,1.46478,4.50623-2.11987-.75723-4.41754-1.09024-4.91144-.2305-.53729,.93518,1.21948,3.00293,3.13147,4.49875-2.53485,.11649-5.47321,.88214-5.55115,2.02481-.06561,.96191,1.91351,1.93423,4.02991,2.49228-2.10712,.79208-4.07568,2.02277-3.89703,2.99805,.21686,1.18369,3.52466,1.59805,6.12543,1.3555-1.94299,1.8642-4.0498,5.20374-3.17059,6.18246,.64435,.71722,2.7207-.02515,4.59552-1.15463-.89978,2.06339-1.38849,4.33304-.56433,4.88434,1.03137,.68994,3.76532-1.54755,5.38983-3.63962-.23828,2.6712,.31866,6.43002,1.59613,6.60434,.98242,.13406,2.12213-1.88861,2.81738-4.0296,.20862,.66647,.45886,1.31668,.73389,1.89011l-.42535,19.32935c-.35345-1.43094-.93842-2.94705-1.87231-4.44519l-.06311,.03934c.08136-1.44589-.11139-7.75262-9.39935-9.64389-2.19055-.44604-4.24988-.75089-6.13757-.95401l.00018-.00006Zm16.93048,39.62045l-.06958,3.16229c-.06366-.88736-.07074-1.96661,.06958-3.16229Z" fill="#f2f2f2"></path><path d="M691.10928,320.50921H1.57104c-.87128,0-1.57104,.69977-1.57104,1.57108,0,.8714,.69971,1.57108,1.57104,1.57108H691.10928c.87138,0,1.57114-.69968,1.57114-1.57108s-.69975-1.57108-1.57114-1.57108Z" fill="#3f3d56"></path><polygon points="187.55029 118.17785 198.6011 79.07493 225.80316 79.92498 235.15384 111.37732 187.55029 118.17785" fill="#ffb6b6"></polygon><path d="M193.3963,106.99901l-.00003,.00002s-8.07559-2.12517-23.37674,17.4263c-15.30115,19.55144-8.50061,158.96187-8.50061,158.96187l110.93329-25.07687-29.0288-99.9399-5.8238-53.07155-44.20331,1.70013v.00002Z" fill="#6c63ff"></path><g><path id="uuid-b9858c30-f397-4403-a0fe-0b031a3a9912-77" d="M366.45686,142.90533l-36.49368,21.12966,8.01522,14.73706,37.21484-20.36362c3.9959-.20038,7.88572-1.3548,11.34401-3.36667,8.72489-4.91682,13.25945-13.39999,10.13164-18.95069-3.1278-5.55071-12.73366-6.06558-21.45478-1.14934-3.51317,1.91705-6.51604,4.64778-8.75724,7.96361Z" fill="#ffb6b6"></path><polygon points="191.56717 146.19036 267.57108 215.8051 372.23734 165.16674 359.1078 139.0705 284.35672 168.70453 212.68449 111.00562 191.56717 146.19036" fill="#6c63ff"></polygon></g><path d="M166.61932,268.08605l30.60229-48.45361s61.20456-61.20456,84.15628-56.10419c22.95172,5.10037,50.15375,101.15753,50.15375,101.15753l-22.95172,14.45108-40.80304-56.95425s-4.25034,78.20581-16.89084,95.20709c-12.6405,17.00128-63.86517,9.35071-82.56659,0s-1.70013-49.30368-1.70013-49.30368v.00003Z" fill="#2f2e41"></path><polygon points="306.87979 268.93609 310.28003 285.08727 308.57993 295.28805 314.53036 307.18892 361.28384 312.2893 363.83405 290.18767 339.18219 277.4367 321.33087 259.58538 306.87979 268.93609" fill="#ffb6b6"></polygon><path d="M357.88361,303.78869l-2.5502,3.40024-48.96231-14.10971s2.20883,21.76025,2.20883,26.01059,80.75604,4.25034,92.90793,2.5502c12.15189-1.7001,8.24963-12.75095,8.24963-12.75095l-50.39401-23.85458-1.45987,18.75418v.00003Z" fill="#2f2e41"></path><g><polygon points="302.06534 154.01392 343.46597 157.62881 367.81832 150.19365 381.6064 133.35326 392.88104 94.71783 328.57131 65.67645 327.39671 65.14753 318.4853 66.00484 302.43614 152.02112 302.06534 154.01392" fill="#fd6982"></polygon><polygon points="302.43614 152.02112 313.56487 153.53271 328.57131 65.67645 327.39671 65.14753 318.4853 66.00484 302.43614 152.02112" fill="#241f20" opacity=".2"></polygon><path d="M306.60485,159.99427c-1.61721-.128-3.08913-.95557-4.03858-2.27041s-1.27193-2.97262-.88449-4.54823l2.0967-8.52495,.19141,.02588c.11414,.01516,11.54737,1.53996,24.71786,2.09437,17.40542,.73277,29.9255-.55355,36.20647-3.72016,15.46956-7.80306,24.41796-49.93003,24.50639-50.35472l.04085-.19665,3.36381,.46595c1.5216,.21131,2.85763,1.011,3.76127,2.25216,.90181,1.2381,1.25202,2.75029,.98683,4.25777-2.07179,11.78037-8.84895,40.39035-26.98637,51.59762-.17768,.10969-.35479,.21707-.53527,.32452-18.20284,10.83457-50.35468,9.62998-63.42686,8.59685Z" fill="#3f3d58"></path></g><g><path id="uuid-89ceabf5-3d72-4b0e-954e-73915df3a7c3-78" d="M354.47742,147.35355c-3.60071,1.74715-6.73051,4.33139-9.12745,7.53648l-37.46074,19.36345,7.30257,15.10287,38.14453-18.56385c4.00091-.0094,7.94143-.97681,11.49181-2.82129,8.94968-4.49473,13.884-12.75178,11.02474-18.44545-2.85926-5.69367-12.42957-6.66652-21.37543-2.17222l-.00003,.00002Z" fill="#ffb6b6"></path><polygon points="170.50291 149.82247 243.09692 222.98611 350.06122 177.40199 338.1924 150.70874 262.11191 176.74053 193.27579 115.68595 170.50291 149.82247" fill="#6c63ff"></polygon></g><circle cx="213.62604" cy="55.12785" r="39.39541" fill="#ffb6b6"></circle><path d="M200.93696,57.67721c.05771,.00986,.1442,.0245,.24904,.04185,2.05136,.33957,14.45374,2.25308,26.95784-2.51012,5.29715-2.01785,3.49015-2.52077,15.28773-9.53614,13.83138-8.22473,17.38101-8.16726,18.41101-12.0023,2.05667-7.65797-8.92542-19.69644-16.19439-18.90382-1.91376,.20869-3.96328,1.34963-7.15104,.57599-.70038-.16997-3.76626-.91402-5.26088-3.4518-1.33332-2.26389-.20403-3.89699-.74025-5.7537-1.40748-4.87362-13.14017-7.30582-23.42653-5.58734-5.91628,.98842-10.51802,3.68683-19.47981,9.04331-15.59837,9.32311-23.39748,13.98468-25.15035,21.12671-1.66142,6.76935,2.32619,9.68619-.57391,16.93256-2.70041,6.74725-6.98935,6.29661-8.46524,11.75484-2.37505,8.78336,6.44004,18.42314,10.11211,22.4388,4.02599,4.40267,7.87633,6.81902,12.98792,10.02686,6.41596,4.02642,9.62385,6.03962,13.48076,5.83479,6.99272-.37136,13.94788-6.70843,14.21893-12.49513,.10155-2.16864-.80314-2.81903-3.04218-10.2743-.93279-3.10603-1.57983-5.67019-1.97334-7.31533" fill="#2f2e41"></path></svg>
    </div>
  </div>
  <br>
</div>
     <?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/livewire/inicio.blade.php ENDPATH**/ ?>