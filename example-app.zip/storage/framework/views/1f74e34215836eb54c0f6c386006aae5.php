<div>

<div class="flex justify-between mt-8">
    <div class="w-2/4 block">
        <h1 class="text-2xl font-bold mb-2">Lista de Solicitudes</h1>
        <br>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <?php echo e($solicitudes->links()); ?>

            </div>
        </div>
        <div class="mx-auto px-2 sm:px-6 lg:px-8 py-16 mb-40 mr-4">
            <div class="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-4">
                <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-lg shadow-lg transition duration-500 transform hover:scale-105 mb-4 ml-4">
                        <div class="p-6">
                            <h2 class="text-lg font-bold mb-2"><?php echo e($solicitud->titulo); ?></h2>
                            <p class="text-gray-700 mb-2"><?php echo e($solicitud->descripcion); ?></p>
                            <p class="text-violet-700 text-base mb-4"><strong>Ayuda Preferible:</strong> <?php echo e($solicitud->ayuda); ?></p>
                            <p class="text-gray-500 text-sm"><?php echo e($solicitud->created_at->diffForHumans()); ?></p>
                            <form wire:submit.prevent="startChatWithOwner(<?php echo e($solicitud->id); ?>)">
                                <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                    Iniciar Chat
                                </button>
                            </form>
                        </div>
                        <div class="px-6 py-2 flex justify-between items-center text-gray-500 text-xs">
                            <span><?php echo e($solicitud->usuario->name); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="flex flex-col h-full w-1/2" style="padding: 10px;">
        <div class="flex justify-between items-center bg-gray-200 py-2 px-4 rounded-t-lg">
            <h2 class="text-lg font-bold">Mensajes</h2>
            <?php if($Modal): ?>
                <button wire:click="closeChat" class="ml-auto rounded-full bg-red-500 hover:bg-red-600 text-white transition-colors duration-300 focus:outline-none p-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M11.414 10l4.293-4.293a1 1 0 1 0-1.414-1.414L10 8.586 5.707 4.293A1 1 0 1 0 4.293 5.707L8.586 10l-4.293 4.293a1 1 0 1 0 1.414 1.414L10 11.414l4.293 4.293a1 1 0 1 0 1.414-1.414L11.414 10z" clip-rule="evenodd" />
                    </svg>
                </button>
            <?php endif; ?>
        </div>

        <?php if($Modal): ?>
            <div class="bg-white rounded-b-lg flex flex-col justify-between h-full">
                <div class="px-4 py-2 border-b border-gray-200">
                    <div class="mb-2">
                        Usuario actual: <strong><?php echo e($selectedUser->name); ?></strong>
                    </div>
                    <ul class="space-y-2 max-h-[500px] overflow-y-auto" id="messageContainer">
                        <div>
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex mb-2">
                                    <div class="<?php echo e($message->isSent ? 'ml-auto bg-blue-500 text-white' : 'bg-gray-200'); ?> rounded-lg py-2 px-4 max-w-[75%]">
                                        <?php echo e($message->message); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </ul>
                </div>

                <form wire:submit.prevent="sendMessage" class="px-4 py-2 border-t border-gray-200">
                    <div class="flex">
                        <input type="text" wire:model="newMessage" placeholder="Escribe tu mensaje" class="flex-grow border border-gray-300 rounded-l p-2 focus:outline-none focus:ring focus:border-blue-500">
                        <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-r">Enviar</button>
                    </div>
                    <?php $__errorArgs = ['newMessage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </form>
            </div>
        <?php else: ?>
            <div class="flex flex-col items-center justify-center h-full">
                <p class="text-gray-500">Selecciona una petición para empezar un chat.</p>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php if($showModal): ?>
    <div class="fixed inset-0 transition-opacity">
        <div class="fixed inset-0 z-40 bg-black opacity-25"></div>
    </div>
    <div class="fixed inset-0 flex items-center justify-center z-50">
        <div class="bg-white p-4 rounded shadow-lg">
            <p class="mb-4">Ya has enviado un mensaje a este usuario.
            <br>
            Revisa tus chats en el menú de inicio</p>
            <button wire:click="$set('showModal', false)" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Aceptar</button>
        </div>
    </div>
<?php endif; ?>

</div>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<script>
    document.addEventListener('livewire:load', function () {
        Livewire.hook('message.processed', function () {
            var container = document.getElementById('messageContainer');
            container.scrollTop = container.scrollHeight;
        });
    });

</script>
<?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/livewire/brindar-ayuda.blade.php ENDPATH**/ ?>