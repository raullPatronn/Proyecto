<div>
    
</div>
<?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/livewire/seleccionar-rol.blade.php ENDPATH**/ ?>