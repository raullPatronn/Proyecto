<div>
<div>
    <h2>Chat</h2>
    <div>
        
        <div class="chat-window">
            <h3>Chat con <?php echo e($selectedUser ? $selectedUser->name : 'ningún usuario seleccionado'); ?></h3>
            <div class="messages">
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="message">
                    <p class="<?php echo e($message->sender_id == auth()->id() ? 'sent' : 'received'); ?>"><?php echo e($message->content); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="message-input">
                <form wire:submit.prevent="sendMessage">
                    <input type="hidden" name="recipient_id" value="<?php echo e($recipient->id); ?>">
                    <input type="text" name="message" wire:model="newMessage">
                    <button type="submit">Enviar</button>
                </form>
            </div>
        </div>
    </div>
</div>

</div>
<script src="https://cdn.tailwindcss.com"></script><?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/chat.blade.php ENDPATH**/ ?>