<div>
     <div class="flex space-x-4 ">
        <div class="bg-white shadow-md rounded-lg p-6">
            <a href="rol-solicitud"><h2 class="text-2xl font-bold mb-4">Solicitar ayuda</h2></a>
            <div class="flex items-center justify-center bg-gray-100 rounded-lg p-4">
                <p class="text-4xl font-bold text-blue-500"><?php echo e($countRole1); ?></p>
            </div>
        </div>
        <div class="bg-white shadow-md rounded-lg p-6">
             <a href="rol-ayuda"><h2 class="text-2xl font-bold mb-4">Guia espiritual</h2></a>
            <div class="flex items-center justify-center bg-gray-100 rounded-lg p-4">
                <p class="text-4xl font-bold text-green-500"><?php echo e($countRole2); ?></p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/livewire/vista-admin.blade.php ENDPATH**/ ?>