<div>
<div class="container mx-auto px-4 py-8">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
            <div class="bg-white shadow-md rounded-lg p-6">
                <h2 class="text-2xl font-bold mb-4">Usuarios del rol 1</h2>

                <?php if($users->count() > 0): ?>
                    <table class="table-auto w-full">
                        <thead>
                            <tr>
                                <th class="px-4 py-2">ID</th>
                                <th class="px-4 py-2">Nombre</th>
                                <th class="px-4 py-2">Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border px-4 py-2"><?php echo e($user->id); ?></td>
                                    <td class="border px-2 py-2"><?php echo e($user->name); ?></td>
                                    <td class="border px-2 py-2"><?php echo e($user->email); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="mt-4">No hay usuarios disponibles.</p>
                <?php endif; ?>
            </div>
        </div>

        <div>
            <div class="bg-white shadow-md rounded-lg p-6">
                <h2 class="text-2xl font-bold mb-4">Actualizar Rol</h2>

                <?php if(session()->has('message')): ?>
                    <div x-data="{ show: true }"
                         x-init="setTimeout(() => { show = false; }, 2000)"
                         x-show="show"
                         class="mt-4 flex items-center justify-center">
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                            <span class="block sm:inline"><?php echo e(session('message')); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <form wire:submit.prevent="updateRole">
                    <div class="mb-4">
                        <label for="user" class="block text-gray-700 text-sm font-bold mb-2">Seleccionar Usuario:</label>
                        <select id="user" wire:model="selectedUser" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-indigo-500">
                            <option value="">Seleccione un usuario</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <?php if($selectedUser): ?>
                        <div class="mb-4">
                            <label for="role" class="block text-gray-700 text-sm font-bold mb-2">Rol:</label>
                            <select id="role" wire:model="selectedRole" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-indigo-500">
                                <option value="">Seleccione un rol</option>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <?php if($selectedUser && $selectedRole): ?>
                        <button type="submit" class="bg-indigo-500 text-white px-4 py-2 rounded-md hover:bg-indigo-600 focus:outline-none focus:bg-indigo-600">Actualizar Rol</button>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<br>
</div>
<?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/livewire/rol-solicitud.blade.php ENDPATH**/ ?>