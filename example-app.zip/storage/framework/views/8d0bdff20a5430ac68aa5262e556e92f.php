<div>
    <div>
    <h2>Usuarios relacionados en los chats</h2>
    <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($user->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

</div>
<?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/livewire/vista-chat.blade.php ENDPATH**/ ?>