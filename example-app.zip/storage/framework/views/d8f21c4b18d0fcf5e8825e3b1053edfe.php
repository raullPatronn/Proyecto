<div>
    <div class="flex items-center mx-8">
    <a href="<?php echo e(route('dashboard')); ?>" id="btnAbrirModal" class="bg-violet-400 hover:bg-violet-600 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out transform hover:-translate-y-1 hover:scale-110 flex items-center justify-center">
  <svg class="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
  </svg>
  <span>Regresar</span>
    </a>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\Lavarel-Jet\example-app\resources\views/livewire/btn-regresar.blade.php ENDPATH**/ ?>