<?php

namespace App\Http\Livewire;

use Livewire\Component;

class BtnEditar extends Component
{
    public function render()
    {
        return view('livewire.btn-editar');
    }
}
