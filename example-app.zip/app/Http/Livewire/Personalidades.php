<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Personalidades extends Component
{
    public function render()
    {
        return view('livewire.personalidades');
    }
}
